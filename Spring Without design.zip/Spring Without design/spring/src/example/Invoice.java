package example;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class Invoice extends TagSupport 
{

	
	@Override
	public int doEndTag() throws JspException
	{
		
		
		HttpSession session=pageContext.getSession();
		JspWriter out=pageContext.getOut();
		 Enumeration<String> e=session.getAttributeNames();
		 while(e.hasMoreElements())
		 {
		 	String attributename=e.nextElement();
		 	String attributevalue=session.getAttribute(attributename).toString();
		 	try 
		 	{
		 		if(attributename.equalsIgnoreCase("username") || attributename.equals("rb"))
		 		{
		 			
		 		}
		 		else
		 		{
				out.println(attributename+""+attributevalue);
		 		}
		 	} catch (Exception e1) {}
		
		 }
		return super.doEndTag();
	}
}


